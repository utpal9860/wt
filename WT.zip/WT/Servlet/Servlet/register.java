import java.sql.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public register() {
        
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String fn=request.getParameter("name");
		String e=request.getParameter("email");
		String un=request.getParameter("username");
		String p1=request.getParameter("password");
		String mb=request.getParameter("mblno");
		
		try
		{
		
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sk","root","");
			
			String q="insert into student values(?,?,?,?,?);";
			
			PreparedStatement ps=con.prepareStatement(q);
			
			ps.setString(1, fn);;
			ps.setString(2, un);
			ps.setString(3, p1);
			ps.setString(4, e);
			ps.setString(5, mb);
			
			int i=ps.executeUpdate();
			response.sendRedirect("welcome.html");
			con.close();
			
		}catch (Exception e1) {
			
			System.out.println("Error During Connection to the Database" +e1.getMessage());
		}
		
	/*	Database db=new Database();
		db.saveData(p);
		response.sendRedirect("UserLogin.html");*/
		
	}
		
		
		
		
		
	}


