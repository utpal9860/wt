/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.proj.EJB;

import javax.ejb.Stateless;

/**
 *
 * @author devil
 */
@Stateless
public class LoginExample implements LoginExampleRemote {

    @Override
    public String validateUser(String username, String password) {
        if(username.equals(password))
        {
            return "Valid User";
        
    }
        else
            return "Invalid User";

   
}
}
